/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Robotics                                         */
/*    Created:      Tue Mar 16 2021                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Motor1               motor         1               
// Motor10              motor         10              
// Motor11              motor         11              
// Motor20              motor         20              
// Controller1          controller                    
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  while(true) {
    Motor1.spin(vex::directionType::rev, Controller1.Axis3.value(), vex::velocityUnits::pct);
    Motor10.spin(vex::directionType::rev, Controller1.Axis2.value(), vex::velocityUnits::pct);
    Motor11.spin(vex::directionType::rev, Controller1.Axis3.value(), vex::velocityUnits::pct);
    Motor20.spin(vex::directionType::rev, Controller1.Axis2.value(), vex::velocityUnits::pct);

  }
}
